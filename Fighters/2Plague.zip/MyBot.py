"""
"""
import hlt
import logging


#
# key: ship_id
# value: {
#   "task": str   ["free", "intransit", "mining", "attacking"],
#   "target": id  ["    ", "going_to",  "planet", "enemyship"]
# }
# CAVEAT: assumes value is always planet
#
assignments = {}


def get_assignment(ship):
    if ship.docking_status != ship.DockingStatus.UNDOCKED:
        return "mining"
    if ship.id in assignments:
        return "intransit"
    else:
        return False  # free


def split_by_task(ships):
    """
    Returns dictionary keyed by taskstring
    values being lists of ships assigned to that task.
    """
    vals = {
        False: [],
        "intransit": [],
        "mining": []
    }
    for l in ships:
        val = get_assignment(l)
        try:
            vals[val].append(l)
        except KeyError:
            vals[val] = [l]  # other options may arise
    return vals


def _engage(ship, target, MAP):
    """
    ship engages target
    if target is a planet, tries to dock or moves toward planet.
    else, moves toward target.
    """
    if isinstance(target, hlt.entity.Planet):
        if ship.can_dock(target):
            return ship.dock(target)
        else:
            #


            if ship.id in assignments:
                return False  # unassign me

    return ship.navigate(ship.closest_point_to(target), MAP,
                         speed=int(hlt.constants.MAX_SPEED))


GAME = hlt.Game("Plague")
logging.info("Starting my bot!")

#
#
#
###
### Game Start
###
#
#
#
while True:
    MAP = GAME.update_map()
    ME = MAP.get_me()
    commands = []

    # ownership
    def mine(p):
        return p.owner == MAP.my_id

    def empty(p):
        return not p.is_owned()

    def someone_elses(p):
        return not empty(p) and not mine(p)

    # fullness
    def spaces_left(p):
        return max(p.num_docking_spots - len(p._docked_ship_ids), 0)

    def suitable(p):
        return (mine(p) and spaces_left(p) > 0) or empty(p)

    def engage(ship, target):

        # Planet
        if isinstance(target, hlt.entity.Planet):

            # find something better to do
            if mine(target) and not spaces_left(target):
                return False

            # dock if you can
            if ship.can_dock(target):
                target.num_docking_spots -= 1  # prevent too many dock attempts
                return ship.dock(target)

        return ship.navigate(ship.closest_point_to(target), MAP,
                             speed=int(hlt.constants.MAX_SPEED))

    def nearby_entities(entity):
        ent_by_dist = MAP.nearby_entities_by_distance(entity)
        near = []
        for d, ents in sorted(ent_by_dist.items(), key=lambda d: d[0]):
            near.extend(ents)
        return near

    def nearby_planets(entity, where=lambda _: True):
        #
        # Set up well for scoring planets for each ship
        #
        near = nearby_entities(entity)
        return list(filter(lambda e: isinstance(e, hlt.entity.Planet) and
                           where(e), near))

    # What is everyone doing?
    assigned = split_by_task(ME.all_ships())

    #
    # Ships in transit continue to engage their assignment
    #
    for ship in assigned["intransit"]:
        planet = MAP.get_planet(assignments[ship.id])

        # if you've got somewhere better to be...
        if mine(planet) and not spaces_left(planet):
            assigned[False].append(ship)
            del assignments[ship.id]
            logging.info("Freed (bad target) {}".format(ship.id))

        else:
            # caveat: assuming all intransit are heading to a planet
            command = engage(ship, planet)
            if not command:  # set free
                assigned[False].append(ship)
                del assignments[ship.id]
                logging.info("Freed (failed command) {}".format(ship.id))
            else:  # keep in transit
                commands.append(command)
    logging.info("{} ships in transit continue".format(len(assignments)))

    #
    # Ships mining stay mining
    #
    logging.info("{} ships mining stay mining".format(len(assigned["mining"])))

    #
    # Free ships get assigned to planets
    #

    # Any free ships?
    if not assigned[False]:
        GAME.send_command_queue(commands)
        continue

    logging.info("Assigning {} free ships".format(len(assigned[False])))

    #
    # Free ships engage nearest suitable planet
    #
    for freeship in assigned[False]:
        for p in nearby_planets(freeship, where=suitable):
            command = engage(freeship, p)
            if command:
                logging.info("{} will mine {}".format(freeship.id, p.id))
                logging.info(nearby_planets(freeship))
                assignments[freeship.id] = p.id
                commands.append(command)
                assigned[False].remove(freeship)  # no longer free
                break

    #
    # Remaining free ships focus fire on most average unsuitable planet
    #
    if len(assigned[False]) > 0:
        logging.info("Leftovers: {}".format(len(assigned[False])))
        avgx = sum(map(lambda s: s.x, assigned[False])) / len(assigned[False])
        avgy = sum(map(lambda s: s.y, assigned[False])) / len(assigned[False])
        center = hlt.entity.Position(avgx, avgy)
        for target in nearby_planets(center, where=someone_elses):
            logging.info("Targeting {}".format(target.id))
            for freeship in assigned[False]:
                command = engage(freeship, target)
                if command:
                    logging.info("Sending {}".format(freeship.id))
                    assignments[freeship.id] = target.id
                    commands.append(command)
                    assigned[False].remove(freeship)
                    continue

            # if no more free ships, stop assigning
            if not len(assigned[False]):
                break

    GAME.send_command_queue(commands)
    # TURN END
# GAME END
