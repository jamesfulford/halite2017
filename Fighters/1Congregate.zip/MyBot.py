"""
"""
import hlt
import logging


#
# key: ship_id
# value: id_of_entity_engaging
# CAVEAT: assumes value is always planet
#
assignments = {}


def get_assignment(ship):
    if ship.docking_status != ship.DockingStatus.UNDOCKED:
        return "mining"
    if ship.id in assignments:
        return "intransit"
    else:
        return False  # free


def split_by_task(ships):
    """
    Returns dictionary keyed by taskstring
    values being lists of ships assigned to that task.
    """
    vals = {
        False: [],
        "intransit": [],
        "mining": []
    }
    for l in ships:
        val = get_assignment(l)
        try:
            vals[val].append(l)
        except KeyError:
            vals[val] = [l]  # other options may arise
    return vals


def _engage(ship, target, MAP):
    """
    ship engages target
    if target is a planet, tries to dock or moves toward planet.
    else, moves toward target.
    """
    if isinstance(target, hlt.entity.Planet):
        if ship.can_dock(target):
            return ship.dock(target)

    return ship.navigate(ship.closest_point_to(target), MAP,
                         speed=int(hlt.constants.MAX_SPEED))


GAME = hlt.Game("Congregate")
logging.info("Starting my Engage bot!")


while True:
    MAP = GAME.update_map()
    ME = MAP.get_me()
    commands = []

    # convenience
    engage = lambda s, t: _engage(s, t, MAP)

    # what's everyone doing?
    assigned = split_by_task(ME.all_ships())

    #
    # Ships in transit continue to engage their assignment
    #
    logging.info("{} ships in transit continue".format(len(assigned["intransit"])))
    for ship in assigned["intransit"]:
        # caveat: assuming all intransit are heading to a planet
        command = engage(ship, MAP.get_planet(assignments[ship.id]))
        if not command:  # set free
            assigned[False].append(ship)
            del assignments[ship.id]
        else:  # keep in transit
            commands.append(command)

    #
    # Ships mining stay mining
    #
    logging.info("{} ships mining stay mining".format(len(assigned["mining"])))

    #
    # Free ships get assigned to planets
    #

    # Any free ships?
    if not assigned[False]:
        GAME.send_command_queue(commands)
        continue

    logging.info("Assigning {} free ships".format(len(assigned[False])))

    avgx = sum(map(lambda s: s.x, assigned[False])) / len(assigned[False])
    avgy = sum(map(lambda s: s.y, assigned[False])) / len(assigned[False])
    CENTER = hlt.entity.Position(avgx, avgy)

    ENTITIES = []
    for d, ents in MAP.nearby_entities_by_distance(CENTER).items():
        ENTITIES.extend(ents)

    PLANETS = list(filter(lambda t: isinstance(t, hlt.entity.Planet), ENTITIES))
    open_land = list(filter(lambda p: not p.is_owned() or (not p.is_full() and
                                                      p.owner == MAP.my_id),
                       PLANETS))

    logging.info(str(len(PLANETS)) + " planets")
    logging.info(str(len(open_land)) + " open planets")

    for e in ENTITIES:
        if isinstance(e, hlt.entity.Planet):
            # allocate right number of free ships to planet
            open_spots = e.num_docking_spots - len(e._docked_ship_ids)
            i = 0
            while open_spots > 0 and i < len(assigned[False]):
                envoy = assigned[False][i]
                command = engage(envoy, e)
                if command:
                    assignments[assigned[False].pop(i).id] = e.id
                    commands.append(command)
                    open_spots -= 1
                else:
                    logging.info("Not assigning {} to {}".format(envoy, e))
                    i += 1
        elif isinstance(e, hlt.entity.Ship):
            pass

        if len(assigned[False]) <= 0:
            break  # ran out

    #
    # Remaining freeships
    #
    # if len(assigned[False]) > 0:  # some left over?
    #     for free in freeships:
    #         command = engage(free, CENTER)

    #         commands.append()

    GAME.send_command_queue(commands)
    # TURN END
# GAME END
